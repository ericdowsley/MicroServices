package br.com.fiap.ms_pagamento.model;

public enum Status {

    CRIADO,
    CONFIRMADO,
    CANCELADO
}
