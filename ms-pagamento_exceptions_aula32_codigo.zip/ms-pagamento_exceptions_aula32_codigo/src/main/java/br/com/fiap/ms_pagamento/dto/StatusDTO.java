package br.com.fiap.ms_pagamento.dto;

import br.com.fiap.ms_pagamento.model.Status;
import lombok.Getter;

@Getter
public class StatusDTO {

    private Status status;
}
