package br.com.fiap.ms_pagamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsPagamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
